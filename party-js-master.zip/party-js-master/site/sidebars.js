module.exports = {
  someSidebar: {
    'Documentation': ['quick-start','emitting-particles','shapes','customization','technical-details'],
    'Other': ['examples']
  },
};
